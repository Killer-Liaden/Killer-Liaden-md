module.exports = {
modul: {
	axios: require('axios'),
	boom: require('@hapi/boom'),
	baileys: require('@whiskeysockets/baileys'), 
	chalk: require('chalk'),
	cheerio: require('cheerio'),
	child_process: require('child_process'),
	util: require('util'),
    Utils: require('@whiskeysockets/baileys/lib/Utils'),
	fs: require('fs'),
	fetch: require('node-fetch'),
	FormData: require('form-data'),
	FileType: require('file-type'),
	speed: require('performance-now'),
    yargs: require('yargs'),
	process: require('process'),
	path: require('path'),
    api: require('api-dylux'),
    googleTTS: require('google-tts-api'),
	PhoneNumber: require('awesome-phonenumber')
}
}